# -*- coding: utf-8 -*-
# one_chapter_to_sql.py — Extract one chapter (FA + optional EN) → SQL dump
import argparse, re, sys
from pathlib import Path
from bs4 import BeautifulSoup

FA_NUMS = "۰۱۲۳۴۵۶۷۸۹"
FA_TO_EN = {ord(FA_NUMS[i]): str(i) for i in range(10)}

def clean(t: str) -> str:
    if not t: return ""
    t = t.replace("\xa0"," ").replace("\r"," ").replace("\t"," ")
    return re.sub(r"\s+"," ", t, flags=re.M).strip()

def sql_escape(v):
    return "NULL" if v is None else "'" + str(v).replace("'", "''") + "'"

def extract_verses_wp_from_html(html_text: str):
    """WordProject: آیه 1 قبل از اولین span.verse؛ بقیه با span.verse."""
    if not html_text: return []
    soup = BeautifulSoup(html_text, "lxml")

    # ناحیه اصلی متن؛ همان‌طور که در فایل نمونه‌ی شما (1.html) هست
    p = soup.select_one("#textBody p")
    if p:
        verses = {1: []}
        cur = 1
        for node in p.children:
            name = getattr(node, "name", None)

            if name == "span" and "verse" in (node.get("class") or []):
                lab = node.get("id") or node.get_text(strip=True).translate(FA_TO_EN)
                try:
                    cur = int(re.sub(r"\D","", lab)) if lab else cur + 1
                except:
                    cur = cur + 1
                verses.setdefault(cur, [])
                continue

            if name == "br":
                continue

            text = node if isinstance(node, str) else node.get_text(" ", strip=True)
            text = clean(str(text))
            if text:
                verses.setdefault(cur, [])
                verses[cur].append(text)

        out = []
        for vn in sorted(verses.keys()):
            txt = clean(" ".join(verses[vn]))
            if txt: out.append((vn, txt))
        if out: return out

    # fallback های ایمن
    spans = soup.select("span.verse")
    if spans:
        out = [(i+1, clean(sp.get_text())) for i, sp in enumerate(spans)]
        if out: return out

    tmp = []
    for pp in soup.select("p"):
        t = clean(pp.get_text(" ").translate(FA_TO_EN))
        m = re.match(r"^(\d{1,3})\s+(.*)$", t)
        if m:
            vn = int(m.group(1)); vt = clean(m.group(2))
            if vn >= 1 and vt: tmp.append((vn, vt))
    if tmp:
        tmp.sort(key=lambda x: x[0]); return tmp

    body = clean(soup.get_text("\n").translate(FA_TO_EN))
    rgx = re.compile(r"(?s)(?:^|\s)(\d{1,3})\s+(.*?)(?=\s\d{1,3}\s+|$)")
    out = []
    for m in rgx.finditer(body):
        vn = int(m.group(1)); vt = clean(m.group(2))
        if vn >= 1 and vt: out.append((vn, vt))
    out.sort(key=lambda x:x[0]); return out

def guess_audio(html_text: str) -> str|None:
    if not html_text: return None
    soup = BeautifulSoup(html_text, "lxml")
    a = soup.select_one('.textAudio a[href$=".mp3"]') or soup.select_one('a[href$=".mp3"]')
    return a.get("href") if a else None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fa", required=True, help="مسیر HTML فارسی (مثلاً ...\\fa\\18\\1.html)")
    ap.add_argument("--en", help="مسیر HTML انگلیسی (اختیاری)")
    ap.add_argument("--book-id", type=int, required=True, help="شناسه کتاب (1..66)")
    ap.add_argument("--chapter", type=int, required=True, help="شماره فصل")
    ap.add_argument("--out-sql", default="chapter_dump.sql", help="مسیر خروجی SQL")
    args = ap.parse_args()

    fa_path = Path(args.fa)
    en_path = Path(args.en) if args.en else None
    if not fa_path.exists():
        print("❌ فایل فارسی پیدا نشد:", fa_path); sys.exit(1)
    if en_path and not en_path.exists():
        print("⚠️ فایل انگلیسی پیدا نشد، فقط فارسی خروجی می‌دهم:", en_path); en_path = None

    fa_html = fa_path.read_text(encoding="utf-8", errors="ignore")
    en_html = en_path.read_text(encoding="utf-8", errors="ignore") if en_path else ""

    fa_verses = extract_verses_wp_from_html(fa_html)
    en_verses = extract_verses_wp_from_html(en_html) if en_html else []

    fa_map = {n:t for n,t in fa_verses}
    en_map = {n:t for n,t in en_verses}
    verse_nums = sorted(set(fa_map.keys()) | set(en_map.keys()))

    # تولید chapter_id یکتا: book_id*1000 + chapter (ساده و قابل پیش‌بینی)
    chapter_id = args.book_id * 1000 + args.chapter

    audio_link = guess_audio(fa_html) or guess_audio(en_html)
    audio_online_fa = audio_link or None
    audio_online_en = audio_link or None
    audio_local = None  # اگر فایل mp3 محلی داری، اینجا مقدار بده

    with open(args.out_sql, "w", encoding="utf-8") as f:
        f.write("BEGIN TRANSACTION;\n\n")
        f.write("""CREATE TABLE IF NOT EXISTS chapters(
  id INTEGER PRIMARY KEY,
  book_id INTEGER NOT NULL,
  chapter_number INTEGER NOT NULL,
  audio_local TEXT,
  audio_online_fa TEXT,
  audio_online_en TEXT
);
CREATE TABLE IF NOT EXISTS verses(
  id INTEGER PRIMARY KEY,
  chapter_id INTEGER NOT NULL,
  verse_number INTEGER NOT NULL,
  text_fa TEXT,
  text_en TEXT
);\n""")

        f.write("INSERT INTO chapters VALUES ({},{},{},{},{},{});\n".format(
            chapter_id, args.book_id, args.chapter,
            sql_escape(audio_local),
            sql_escape(audio_online_fa),
            sql_escape(audio_online_en)
        ))

        verse_pk = chapter_id * 100000
        for vn in verse_nums:
            verse_pk += 1
            f.write("INSERT INTO verses VALUES ({},{},{},{},{});\n".format(
                verse_pk, chapter_id, vn,
                sql_escape(fa_map.get(vn)),
                sql_escape(en_map.get(vn))
            ))

        f.write("COMMIT;\n")

    print("✅ ساخته شد →", args.out_sql)
    print(f"آیات استخراج‌شده: فارسی={len(fa_verses)} | انگلیسی={len(en_verses)}")

if __name__ == "__main__":
    sys.exit(main())
