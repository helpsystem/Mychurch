// This file provides type definitions for environment variables
// accessed via `process.env`. It ensures type safety across the application.

declare namespace NodeJS {
  interface ProcessEnv {
    /**
     * The base URL for the backend API. Can be set during a build process.
     * This value can be overridden by the user in the admin settings.
     */
    readonly VITE_API_BASE_URL?: string;

    /**
     * The API key for the Google Gemini service.
     */
    readonly API_KEY?: string;
  }
}
